// PostList.js
import React from "react";

import Post from "../components/Post";

const PostList = (props) => {
console.log(props);
    return (
        <React.Fragment>
            <Post apple="aa"/>
        </React.Fragment>
    )
}

export default PostList;
