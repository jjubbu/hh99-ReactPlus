import React from "react";

const Upload = (props) => {

    return (
        <React.Fragment>
            <input type="file"/>
        </React.Fragment>
    )
}

export default Upload;